package de.leostrakosch.reminder.common;

public class Date {

  public final static String FORMAT = "UNKNOWN";
}