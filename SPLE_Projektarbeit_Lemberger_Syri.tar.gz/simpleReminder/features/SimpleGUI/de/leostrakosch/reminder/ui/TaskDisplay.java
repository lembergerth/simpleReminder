package de.leostrakosch.reminder.ui;

public interface TaskDisplay {

  void displayTasks();
}