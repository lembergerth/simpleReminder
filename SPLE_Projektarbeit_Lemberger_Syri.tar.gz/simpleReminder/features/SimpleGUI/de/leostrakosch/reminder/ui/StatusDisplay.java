package de.leostrakosch.reminder.ui;

public interface StatusDisplay {

  void displayStatus(String msg);
  
  void displayError(String msg);
}