package de.leostrakosch.reminder.cli;

public enum Command {
	ADD, DELETE, LIST, HELP
}
