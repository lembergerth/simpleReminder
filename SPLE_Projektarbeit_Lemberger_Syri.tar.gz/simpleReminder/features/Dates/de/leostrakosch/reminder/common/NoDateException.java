package de.leostrakosch.reminder.common;


public class NoDateException extends Exception {
	public NoDateException(String error) {
		super(error);
	}
}