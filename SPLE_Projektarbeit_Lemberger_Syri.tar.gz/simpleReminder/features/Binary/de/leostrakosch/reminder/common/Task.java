package de.leostrakosch.reminder.common;

import java.io.Serializable;

public class Task implements Serializable {

}