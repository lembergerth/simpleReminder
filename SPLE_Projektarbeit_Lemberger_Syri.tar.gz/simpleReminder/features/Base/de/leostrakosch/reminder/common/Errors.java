package de.leostrakosch.reminder.common;

public final class Errors {
    public static final String ERR_WRONG_ARG_NUMBER = "Wrong number of arguments";

    private Errors() {

    }

}
