package de.leostrakosch.reminder.cli.updates;

import java.util.List;

public class TaskUpdate {
}